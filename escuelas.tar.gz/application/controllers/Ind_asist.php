<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ind_asist extends CI_Controller {
	function index()
	{
		$this->load->view('/ind_asistencia/index.php');
	}

	public function getFilterIndAsistencia()
	{
		var_dump($_POST);

		return json_encode($_POST);
	}
}
